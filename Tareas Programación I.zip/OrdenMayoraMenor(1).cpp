#include <iostream>
using namespace std;

int main()


{
	int num[10];
	cout<<"Ingrese 10 numeros: ";
	
	for(int i=0; i<10; i++)
	{
		
	cin>> num[i];
			
	}
	
	for( int i=0;)


	
	


}


