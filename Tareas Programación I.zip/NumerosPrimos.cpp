#include <iostream>
using namespace std;

int main() {
    int num;
    bool es_primo = true;

    cout << "Ingrese un número entero positivo: ";
    cin >> num;

    // Comprobamos si el número es primo
    for (int i = 2; i <= num / 2; i++) {
        if (num % i == 0) {
            es_primo = false;
            cout << "El número no es primo. Sus divisores son: ";
            for (int j = 2; j <= num / 2; j++) {
                if (num % j == 0) {
                    cout << j << " ";
                }
            }
            break;
        }
    }

    if (es_primo) {
        cout << "El número es primo.";
    }

    return 0;
}

