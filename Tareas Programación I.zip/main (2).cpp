/******************************************************************************

                 programa que pida al usuario, determine y escriba en pantalla 
                             el mayor, menor y el promedio
*******************************************************************************/

#include <iostream>
using namespace std;

int main() {
    int num, max, min, sum = 0;
    double promedio;

    // Pedimos al usuario 10 números
    for (int i = 1; i <= 10; i++) {
        cout << "Introduzca el número " << i << ": ";
        cin >> num;

        // Si es el primer número, lo consideramos el mayor y el menor
        if (i == 1) {
            max = num;
            min = num;
        }

        // Si no, comparamos con los anteriores para actualizar el mayor y menor
        else {
            if (num > max) {
                max = num;
            }
            if (num < min) {
                min = num;
            }
        }

        // Acumulamos la suma de los números para calcular el promedio
        sum += num;
    }

    // Calculamos el promedio
    promedio = static_cast<double>(sum) / 10;

    // Mostramos los resultados
    cout << "El número mayor es: " << max << endl;
    cout << "El número menor es: " << min << endl;
    cout << "El promedio es: " << promedio << endl;

    return 0;
}
