#include <iostream>
using namespace std;
int main()


{
	float a,b,c,d,e, prom=0;
	cout<<"Ingrese 5 calificaciones : " ;
	cin>> a>>b>>c>>d>>e;
	prom=(a+b+c+d+e)/5;
	cout<<"Su promedio es:"<<prom;
	
	return 0;
}
