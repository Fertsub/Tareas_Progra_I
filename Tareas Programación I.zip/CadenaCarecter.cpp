#include <iostream>
#include <string>
using namespace std;
int main() {



	
    int numero;
    string cadena;

    for (int i = 1; i <= 5; i++) {
        cout << "Ingrese el numero " << i << ": ";
        cin >> numero;

        if (numero <= 0) {
            break;
        }

        string cadena=(cadena);
    }

    cout << "La cadena resultante es: " << cadena << endl;

    
	return 0;
}
